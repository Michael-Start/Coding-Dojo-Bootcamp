const { application } = require("express");
const express = require("express");
const app = express();
const port = 8000;
app.use(express.json());
app.use(express.urlencoded({extended:true}));


const faker = require ('faker')

const newCompany =() =>{
    const company ={
        id : faker.datatype.uuid(),
        name: faker.company.companyName(),
        city: faker.address.city(),
        address: faker.address.streetAddress(),
        state: faker.address.state(),
        zipCode: faker.address.zipCode(),
        country: faker.address.country()
        
    };
    return company;
};

const newUser = ()=>{
    const user ={
        id: faker.datatype.uuid(),
        firstName: faker.name.firstName(),
        lastName: faker.name.lastName(),
        email: faker.internet.email(),
        password: faker.internet.password(10,true),
        phoneNumber: faker.phone.phoneNumberFormat()
    };
    return user
};

const newFakeCompany = newCompany();


const newFakeUser = newUser()


app.get('/api/user/new' ,(req, res)=>{
    newFakeUser;
    res.json(newFakeUser);
});

app.get ('/api/companies/new', (req, res)=>{
    newFakeCompany;
    res.json(newFakeCompany);
});

app.get('/api/user/company', (req, res)=>{
    obj = {newFakeCompany, newFakeUser}
    res.json(obj)
})




app.listen( port, () => console.log(`Listening on port: ${port}`) );
